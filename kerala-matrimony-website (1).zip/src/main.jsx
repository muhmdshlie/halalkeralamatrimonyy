import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ChevronDown, ChevronRight, Search, Heart, ShieldCheck, Users,
  MessageCircle, Headphones, MapPin, Mail, Smartphone, Star
} from "lucide-react";
import "./styles.css";

const pink = "#f34b69";

function Header() {
  return (
    <header className="header">
      <a className="brand" href="#top">HALAL<span>NIKAH</span></a>
      <nav>
        <a href="#why">WHY US</a>
        <a href="#about">ABOUT US</a>
        <a href="#success">SUCCESS STORIES</a>
        <a href="#faq">FAQ</a>
      </nav>
      <div className="header-actions">
        <button className="login">Login</button>
        <button className="signup">Register</button>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="hero" id="top">
      <div className="hero-copy">
        <div className="eyebrow">KERALA'S #1 MUSLIM MATRIMONY</div>
        <h1>FIND YOUR LIFE<br />PERFECT <span>PARTNER</span></h1>
        <p>Kerala's #1 Muslim<br />Matrimony Website</p>
        <div className="hero-buttons">
          <button className="primary">Register for Free</button>
          <button className="outline">Login</button>
        </div>
      </div>
      <div className="hero-photo-wrap">
        <img
          src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80"
          alt="Happy couple"
        />
      </div>
      <div className="search-panel">
        <label>I'm looking for</label>
        <select><option>Woman</option><option>Man</option></select>
        <label>Age</label>
        <select><option>21</option><option>25</option><option>30</option></select>
        <label>to</label>
        <select><option>30</option><option>35</option><option>40</option></select>
        <label>Religion</label>
        <select><option>Muslim</option></select>
        <button><Search size={15}/></button>
      </div>
    </section>
  );
}

function WhyUs() {
  const items = [
    ["Verified Profiles", "Authentic profiles reviewed for your safety.", ShieldCheck],
    ["Safe & Secure", "Your privacy and personal details stay protected.", Heart],
    ["Trusted Community", "Connect with genuine people and families.", Users],
    ["100% Muslim", "A focused platform for Muslim matrimonial matches.", Star]
  ];
  return (
    <section className="section why" id="why">
      <p className="section-kicker">WHY CHOOSE US</p>
      <div className="feature-grid">
        {items.map(([title, text, Icon]) => (
          <article className="feature" key={title}>
            <div className="feature-icon"><Icon size={25}/></div>
            <h3>{title}</h3>
            <p>{text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="section about" id="about">
      <p className="section-kicker">ABOUT US</p>
      <h2>Kerala's #1 Muslim Matrimony Website</h2>
      <p className="about-text">
        Find a meaningful connection with people who share your values,
        culture and faith. We make the journey to a happy marriage simple,
        respectful and secure.
      </p>
      <div className="stats">
        <div><strong>1,00,000+</strong><span>Registered</span></div>
        <div><strong>25,000+</strong><span>Matches</span></div>
        <div><strong>5,000+</strong><span>Success Stories</span></div>
      </div>
    </section>
  );
}

function AppDownload() {
  return (
    <section className="app-section">
      <div className="app-person">👩🏻</div>
      <div>
        <p className="section-kicker">MOBILE APP</p>
        <h2>Download Kerala's #1 app for<br/>Muslim Matrimony</h2>
        <div className="stores">
          <button> App Store</button>
          <button>▶ Google Play</button>
        </div>
      </div>
      <div className="phone">📱</div>
    </section>
  );
}

function FAQ() {
  const questions = [
    "How can I register on Halal Nikah?",
    "What are the things I should keep in mind in a matrimonial profile?",
    "How can I search from the matrimonial directory?",
    "Can I change my profile information?",
    "How can I contact another member?"
  ];
  const [open, setOpen] = useState(0);
  return (
    <section className="section faq" id="faq">
      <div className="faq-intro">
        <p className="section-kicker">FREQUENTLY ASKED QUESTIONS</p>
        <p>Learn more about how Halal Nikah works and get answers to common questions.</p>
        <button className="primary">Learn More</button>
      </div>
      <div className="faq-list">
        {questions.map((q, i) => (
          <div className="faq-item" key={q}>
            <button onClick={() => setOpen(open === i ? -1 : i)}>
              <span>{q}</span><ChevronDown size={16} className={open === i ? "rotate" : ""}/>
            </button>
            {open === i && <p>We keep the process simple. Create your profile, add your preferences, browse suitable profiles and connect respectfully.</p>}
          </div>
        ))}
      </div>
    </section>
  );
}

function SuccessStories() {
  return (
    <section className="section success" id="success">
      <p className="section-kicker">SUCCESS STORIES</p>
      <article className="story">
        <img src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=600&q=80" alt="Wedding couple"/>
        <div>
          <h3>"Grateful to Halal Nikah for bringing us together."</h3>
          <p>We found each other through the platform and our families connected. Thank you for helping us begin our journey together.</p>
          <div className="stars">★★★★★</div>
        </div>
      </article>
      <div className="dots"><span className="active"></span><span></span><span></span><span></span></div>
    </section>
  );
}

function SupportBar() {
  return (
    <div className="support-bar">
      <span><MessageCircle/> Support Request</span>
      <span><MessageCircle/> Chat For Assistance</span>
      <span><Headphones/> Hotline 24/7</span>
      <span><MapPin/> Head office — address</span>
    </div>
  );
}

function Footer() {
  return (
    <footer>
      <div className="footer-main">
        <div>
          <h3>Halal Nikah</h3>
          <p>The new way of bringing people together for meaningful relationships, with safety and respect at the heart of every connection.</p>
        </div>
        <div><h3>Company</h3><a href="#about">About</a><a href="#success">Success Stories</a><a href="#faq">FAQ</a><a href="#top">Contact</a></div>
        <div><h3>Help & Support</h3><a href="#faq">Contact Us</a><a href="#faq">FAQs</a><a href="#faq">Report a problem</a><a href="#faq">Privacy policy</a></div>
        <div><h3>Contact</h3><p>+91 00000 00000</p><p>hello@halalnikah.com</p><div className="mini-stores"><span></span><span>▶</span></div></div>
      </div>
      <div className="copyright">© 2026 Halal Nikah. All rights reserved.</div>
    </footer>
  );
}

function App() {
  return (
    <div className="page">
      <Header/>
      <main>
        <Hero/>
        <WhyUs/>
        <About/>
        <AppDownload/>
        <FAQ/>
        <SuccessStories/>
      </main>
      <SupportBar/>
      <Footer/>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App/>);